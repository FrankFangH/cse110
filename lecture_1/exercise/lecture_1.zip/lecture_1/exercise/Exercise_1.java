import java.util.Scanner;

public class Exercise_1 {
    public static void main(String[] args) {
        // Ex 1 尝试写出output
        int grade = 7;
        String level = "freshman";
        System.out.println("He is " + grade + "th grade so he is a/an " + level);
        
        // Ex 2 尝试写出output
        System.out.println("1" + 2 + 3);
        System.out.println("1" + (2 + 3));
        // System.out.println('frank' + (2 + 3));

        int wage = 20;
        System.out.println("My wage is " + wage);

        // Ex 3 找错误
        // int songNum = 5;
        // System.out.println("Num: " + songnum);

        System.out.println("-----------------------");
        
        // Ex 4
        // 写一个小程序，询问用户的工资，并打印出来
        Scanner scan = new Scanner(System.in);
        // wage = scan.nextInt();

        // System.out.print("Salary is ");
        // System.out.println(wage * 40 * 52);
        
        // Ex 5
        // 写一个小程序，询问用户的姓名，年龄，体重，最后打印出 结构为：姓名 + 年龄 + 体重的的一段话
        // 比如：frank is 22 years old with weight of 70kg.
        System.out.print("Enter your name: ");
        String name = scan.nextLine();

        System.out.print("Enter your age: ");
        int age = scan.nextInt();

        System.out.print("Enter your weight: ");
        double weight = scan.nextDouble();
        
        System.out.println(name + " is " + age + " years old with weight of " + weight + "kg");
    }
}