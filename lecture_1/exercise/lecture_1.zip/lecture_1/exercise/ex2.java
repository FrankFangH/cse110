import java.util.Scanner;

public class ex2 {
    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        // Ex 1 写一个时间转换器，你需要要求用户输入小时，然后把它变为分钟。比如，
        //      用户输入1.5小时，你需要打印出90.0分钟。请考虑使用double数据类型

        // Ex 2 写一个时间转换器，你需要要求用户输入分钟，然后把它变为小时。比如，
        //      用户输入90分钟，你需要打印出1.5小时。请考虑使用double数据类型
    }
}